"""Review probes for prithvi_eo_feature_extraction_colab.ipynb (row 69, Notebook Review Framework v1).

CPU only (CUDA_VISIBLE_DEVICES=-1). No terratorch on this host, no HLS Burn Scars tarball: model cells are
exercised with the repository's own stub masked autoencoder (copied from tests/test_adaptation.py) and synthetic
chips (tests/conftest.py); the four example tiles are the real upstream files read from a local weights directory.
Every model-dependent result here is a stand-in observation, labelled as such in results.json.

Usage: python run_probes.py <repo_worktree> <scratch_dir> <weights_dir_with_examples>
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
SCRATCH = Path(sys.argv[2]).resolve()
EXAMPLES_WEIGHTS = Path(sys.argv[3]).resolve()
SCRATCH.mkdir(parents=True, exist_ok=True)
NB_PATH = REPO / "tutorials" / "prithvi_eo_feature_extraction_colab.ipynb"
results: dict = {"env": {"python": sys.version.split()[0], "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}}
t_start = time.time()


def save():
    (SCRATCH / "results.json").write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
markdown = "\n".join(s for c, s in zip(cells, src) if c["cell_type"] == "markdown")
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---- P1 static ------------------------------------------------------------------------------------------
p1: dict = {"n_cells": len(cells), "code_cells": code_idx}
p1["all_code_compiles"] = all(compile(src[i], f"cell{i}", "exec") is not None for i in code_idx)
low = markdown.lower()
p1["guided_markers"] = {k: (k.lower() in low) for k in ("How to use", "Glossary", "Troubleshoot", "Roadmap", "Check your", "Predict", "audience", "Infrastructure", "What to notice", "Expected result", "conclusion", "Look for")}
p1["cellView_form_or_collapsed_cells"] = [i for i in code_idx if cells[i].get("metadata", {}).get("cellView") == "form" or cells[i].get("metadata", {}).get("collapsed") or cells[i].get("metadata", {}).get("jupyter", {}).get("source_hidden")]
p1["carried_module_lines"] = {cells[i]["metadata"]["dimer"]["embedded_module"]: src[i].count("\n") + 1 for i in code_idx if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")}
p1["display_calls_in_tutorial_cells"] = sum(len(re.findall(r"plt\.|imshow|display\(|matplotlib|IPython", src[i])) for i in code_idx if not cells[i].get("metadata", {}).get("dimer"))
p1["brace_typo_present"] = re.findall(r"\{\{id, [a-z, ]+\}\}", markdown)
p1["source_id_index_uses"] = {i: src[i].count("['source_id']") for i in code_idx if "['source_id']" in src[i]}
p1["probe_slice_test_records_1_4"] = "test_records[1:4]" in src[13]
p1["byod_minimum_stated"] = re.findall(r"at least \w+ chips[^.;]*", markdown)
p1["threshold_calibration_in_markdown"] = {"threshold": "threshold" in low, "calibrat": "calibrat" in low, "deployment": "deployment" in low}
p1["section5_resets_probe"] = any(s in src[15] for s in ("pipe.probe = None", "adapter = None", "feature_stats = None"))
p1["metadata_dimer"] = nb["metadata"].get("dimer")
p1["interpretation_hardcodes"] = re.findall(r"[^.]*near 0\.8[^.]*", src[22])
results["P1_static"] = p1
save()

# ---- P2 tooling -----------------------------------------------------------------------------------------
env = dict(os.environ, PYTHONPATH=str(REPO / "src"), PYTHONIOENCODING="utf-8")
p2 = {}
for name, cmd in {
    "build_check": [sys.executable, "tools/build_notebook.py", "--check"],
    "validator": [sys.executable, "tools/validate_release_assets.py"],
    "pytest": [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-o", "addopts=", "tests", "-rs"],
}.items():
    r = subprocess.run(cmd, cwd=REPO, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=500)
    p2[name] = {"exit": r.returncode, "tail": (r.stdout + r.stderr).strip().splitlines()[-4:]}
results["P2_tooling"] = p2
save()

# ---- load carried modules from the notebook cells (exactly what the notebook runs) -----------------------
sys.path.insert(0, str(REPO / "tests"))
import numpy as np  # noqa: E402
import tifffile  # noqa: E402
import torch  # noqa: E402
from conftest import synthetic_chip  # noqa: E402

ns: dict = {"__name__": "__main__"}
for i in code_idx:
    if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module"):
        exec(compile(src[i], f"cell{i}", "exec"), ns)
PFP = ns["PrithviFeaturePipeline"]
PATCH, EMBED_DIM = ns["PATCH"], ns["EMBED_DIM"]


class _StubEncoder(torch.nn.Module):
    """Copied from tests/test_adaptation.py."""

    def __init__(self) -> None:
        super().__init__()
        self.scale = torch.nn.Parameter(torch.ones(1))

    def forward_features(self, x, temporal_coords=None, location_coords=None):
        b, c, t, h, w = x.shape
        pooled = x.reshape(b, c, t, h // PATCH, PATCH, w // PATCH, PATCH).mean(dim=(4, 6))
        tokens = pooled.permute(0, 2, 3, 4, 1).reshape(b, -1, c)
        feats = torch.zeros(b, tokens.shape[1] + 1, EMBED_DIM)
        feats[:, 1:, :c] = tokens * self.scale
        out = []
        for layer in range(24):
            f = feats.clone()
            f[:, :, 6] = float(layer)
            out.append(f)
        return out


class _StubMAE(torch.nn.Module):
    """Copied from tests/test_adaptation.py."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder = _StubEncoder()

    def patchify(self, x):
        b, c, t, h, w = x.shape
        p = x.reshape(b, c, t, h // PATCH, PATCH, w // PATCH, PATCH).permute(0, 2, 3, 5, 4, 6, 1)
        return p.reshape(b, t * (h // PATCH) * (w // PATCH), PATCH * PATCH * c)

    def forward(self, x, temporal_coords=None, location_coords=None, mask_ratio=0.75):
        b, c, t, h, w = x.shape
        n = t * (h // PATCH) * (w // PATCH)
        keep = torch.rand(b, n) >= mask_ratio
        mask = (~keep).float().reshape(b, t, h // PATCH, w // PATCH)
        mask = mask.repeat_interleave(PATCH, dim=2).repeat_interleave(PATCH, dim=3)
        pred = torch.zeros_like(x)
        target = self.patchify(x)
        loss_per_patch = ((self.patchify(pred) - target) ** 2).mean(-1)
        m = self.patchify(mask[:, None].expand(-1, c, -1, -1, -1)).mean(-1)
        return {"loss": (loss_per_patch * m).sum() / m.sum()}, pred, mask


def stub_pipe():
    return PFP(model=_StubMAE(), device="cpu", weights_dir=EXAMPLES_WEIGHTS, source="stub")


# Stand-ins for network/weights-touching calls: a fresh stub on from_pretrained (used by from_artifact),
# a dummy converted record, and fake timm/lightning modules (not installed here; only their versions are printed).
PFP.from_pretrained = classmethod(lambda cls, **kw: stub_pipe())
ns["verify_converted"] = lambda *a, **k: {"files": [{"path": "stand-in"}]}
for fake in ("timm", "lightning"):
    sys.modules.setdefault(fake, types.SimpleNamespace(__version__="stand-in"))


def write_chip_files(n, root: Path, *, seed=0, negatives=()):
    root.mkdir(parents=True, exist_ok=True)
    rows = []
    for k in range(n):
        image, label = synthetic_chip(seed=seed + k)
        if k in negatives:
            label = np.where(label == 1, 0, label)
        tifffile.imwrite(root / f"c{k}.tif", image.astype(np.float32), photometric="minisblack", planarconfig="separate")
        tifffile.imwrite(root / f"c{k}.mask.tif", label.astype(np.int16), photometric="minisblack")
        rows.append((f"chip{k}", f"c{k}.tif", f"c{k}.mask.tif"))
    return rows


def make_zip(n, path: Path, *, drop_member=None, bad_image=False, no_csv=False, negatives=()):
    stage = SCRATCH / ("stage_" + path.stem)
    rows = write_chip_files(n, stage, negatives=negatives)
    with zipfile.ZipFile(path, "w") as z:
        if not no_csv:
            z.writestr("pairs.csv", "id,image,label\n" + "".join(f"{a},{b},{c}\n" for a, b, c in rows))
        for _id, image, label in rows:
            if image == drop_member:
                continue
            if bad_image and image == "c0.tif":
                z.writestr(image, b"not a tiff")
            else:
                z.write(stage / image, image)
            z.write(stage / label, label)
    return path


# ---- P3 BYOD loader + split as Section 4 calls them -------------------------------------------------------
p3 = {}
cases = {f"valid_n{n}": dict(n=n) for n in (4, 5, 6, 7, 8)}
cases.update({
    "missing_member": dict(n=8, drop_member="c3.tif"),
    "non_tiff_image": dict(n=8, bad_image=True),
    "no_pairs_csv": dict(n=8, no_csv=True),
})
for name, kw in cases.items():
    z = make_zip(path=SCRATCH / f"{name}.zip", **kw)
    try:
        s = ns["split_dataset"](ns["load_byod_dataset"](z), seed=0)
        p3[name] = {"ok": True, "sizes": {k: len(v) for k, v in s.items()}, "record_keys": sorted(s["test"][0].keys())}
    except BaseException as exc:  # noqa: BLE001
        p3[name] = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
try:
    next(iter({}.items()))
except BaseException as exc:  # noqa: BLE001  (cell 13: file_name, payload = next(iter(uploaded.items())) on a cancelled upload)
    p3["cancelled_upload_expression"] = f"{type(exc).__name__}: {exc}"
results["P3_byod_loader"] = p3
save()

# ---- cell runner -------------------------------------------------------------------------------------------
WORK = SCRATCH / "nbrun"
WORK.mkdir(exist_ok=True)
os.chdir(WORK)


def run_cell(i, subs=None):
    code = src[i]
    for old, new in (subs or {}).items():
        assert old in code, (i, old)
        code = code.replace(old, new)
    buf = io.StringIO()
    old_out = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(code, f"cell{i}", "exec"), ns)
        status = {"cell": i, "ok": True}
    except BaseException as exc:  # noqa: BLE001
        status = {"cell": i, "ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}", "line": traceback.extract_tb(exc.__traceback__)[-1].line}
    finally:
        sys.stdout = old_out
    status["stdout_tail"] = buf.getvalue().strip().splitlines()[-6:]
    return status


def synthetic_sample():
    out = {"train": [], "validation": [], "test": []}
    k = 0
    for role, n in (("train", 8), ("validation", 4), ("test", 4)):
        for j in range(n):
            image, label = synthetic_chip(seed=100 + k)
            out[role].append(ns["check_record"]({"id": f"{role}-{j:03d}", "source_id": f"T00XXX.2020{k:03d}.v1", "region": f"T00XX{k % 3}", "split": role, "image": image, "label": label, "source": "synthetic"}))
            k += 1
    return out


SAMPLE = synthetic_sample()
ns["fetch_sample_dataset"] = lambda **kw: {k: list(v) for k, v in SAMPLE.items()}
ns["WEIGHTS_DIR"] = EXAMPLES_WEIGHTS
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
results["P4_section1_ci_preinstalled"] = run_cell(3)
ns["MANIFEST"] = {"files": []}
S21 = {"importlib.metadata.version('terratorch')": "'stand-in'"}


def sequence(label, steps):
    out = [run_cell(i, subs) for i, subs in steps]
    results[label] = out
    save()
    return out


def zero_head_eval(records):
    return stub_pipe().evaluate(records)["model"]


# P5 default sample path (synthetic sample + stub; real example tiles)
ns["pipe"] = stub_pipe()
seq_default = sequence("P5_default_cells_stub", [(13, None), (15, None), (17, None), (19, None), (21, S21)])
first_probe_test_iou = ns["adapted_test"]["model"]["iou"]["burn scar"]

# P6 rerun Section 5 after Section 6 (a learner re-running the frozen section, or Run all from Section 4)
seq_rerun5 = sequence("P6_rerun_section5_after_adapt", [(15, None)])
results["P6_summary"] = {
    "true_zero_head_test_burn_iou": zero_head_eval(SAMPLE["test"])["iou"]["burn scar"],
    "probe_test_burn_iou_first_run": first_probe_test_iou,
    "section5_frozen_zero_head_test_burn_iou_on_rerun": ns["frozen_test"]["model"]["iou"]["burn scar"],
    "section5_frozen_test_adapted_flag_on_rerun": ns["frozen_test"]["adapted"],
}
save()

# P7 active learning: FEATURE_LAYER = 23 and CLASS_BALANCE = True, rerun from Section 6 (documented optional experiments)
ns["pipe"] = stub_pipe()
sequence("P7a_default_fresh", [(13, None), (15, None), (17, None), (19, None)])
frozen_before = ns["frozen_test"]["model"]["iou"]["burn scar"]
seq7 = sequence("P7b_feature_layer_23", [(17, {"FEATURE_LAYER = 11": "FEATURE_LAYER = 23"}), (19, None), (21, S21)])
results["P7_summary"] = {
    "feature_layer_after": ns["pipe"].feature_layer,
    "artifact_feature_layer": ns.get("artifact_manifest", {}).get("adapter", {}).get("feature_layer"),
    "epoch0_note": ns["adapt_result"]["history"][0].get("note"),
    "comparison_frozen_column_unchanged": ns["comparison"]["burn_iou"]["frozen_zero_head"] == frozen_before,
    "cells_ok": [s["ok"] for s in seq7],
}
seq7c = sequence("P7c_class_balance", [(17, {"CLASS_BALANCE = False": "CLASS_BALANCE = True"}), (19, None)])
results["P7_summary"]["class_balance_cells_ok"] = [s["ok"] for s in seq7c]
save()

# P8 BYOD: the documented rerun from Section 4 after the default path (google.colab upload stand-in, 8-chip zip)
byod_zip = make_zip(8, SCRATCH / "byod8.zip")
google = types.ModuleType("google")
colab = types.ModuleType("google.colab")
UPLOAD = {"payload": {"byod8.zip": byod_zip.read_bytes()}}
colab.files = types.SimpleNamespace(upload=lambda: UPLOAD["payload"])
google.colab = colab
sys.modules["google"], sys.modules["google.colab"] = google, colab
BYOD = {"USE_BYOD = False": "USE_BYOD = True"}
ns["pipe"] = stub_pipe()
sequence("P8a_default_fresh", [(13, None), (15, None), (17, None), (19, None)])
seq_byod = sequence("P8b_byod_rerun_from_section4", [(13, BYOD), (15, None), (17, None), (19, None), (21, S21)])
results["P8_summary"] = {
    "byod_splits": {k: len(ns["splits"][k]) for k in ("train", "validation", "test")},
    "section4_probe_lines": [l for l in seq_byod[0]["stdout_tail"] if "probe" in l],
    "section5_frozen_zero_head_burn_iou_on_byod": ns["frozen_test"]["model"]["iou"]["burn scar"],
    "true_zero_head_burn_iou_on_byod_test": zero_head_eval(ns["test_records"])["iou"]["burn scar"],
    "section5_frozen_adapted_flag": ns["frozen_test"]["adapted"],
    "section8": seq_byod[-1],
    "result_json_written_for_byod": (WORK / "outputs" / "prithvi_eo_feature_extraction_result.json").exists() and "BYOD" in (WORK / "outputs" / "prithvi_eo_feature_extraction_result.json").read_text(encoding="utf-8"),
}
save()

# P9 BYOD on a fresh kernel (BYOD first) with one chip without burn pixels landing in validation/test
ns["pipe"] = stub_pipe()
mixed = make_zip(10, SCRATCH / "byod10_neg.zip", negatives=(0, 1, 2, 3))
UPLOAD["payload"] = {"byod10_neg.zip": mixed.read_bytes()}
seq9 = sequence("P9_byod_with_negative_chips", [(13, BYOD), (15, None)])
results["P9_summary"] = [(s["cell"], s["ok"], s.get("error")) for s in seq9]
save()

# P10 sample split by tile, and the exported pairs CSV against the extracted member names (static, real constants)
from collections import defaultdict  # noqa: E402

tiles = defaultdict(set)
for name, role, *_ in ns["SAMPLE_RECORDS"]:
    tiles[role].add(name.split(".")[0])
members = {Path(m).name for _n, _r, img, _b, _s, lab, *_ in ns["SAMPLE_RECORDS"] for m in (img, lab)}
recs = [{"id": f"test-{k:03d}", "source_id": n} for k, (n, r, *_) in enumerate(ns["SAMPLE_RECORDS"]) if r == "test"]
csv_path = ns["write_dataset_csv"]([dict(r, image=None, label=None) for r in recs], SCRATCH / "pairs.csv")
import csv as _csv  # noqa: E402

rows = list(_csv.DictReader(open(csv_path, encoding="utf-8")))
results["P10_sample_static"] = {
    "records_per_role": {r: sum(1 for _n, rr, *_ in ns["SAMPLE_RECORDS"] if rr == r) for r in ("train", "validation", "test")},
    "test_tiles_also_in_train": sorted(tiles["test"] & tiles["train"]),
    "validation_tiles_also_in_train": sorted(tiles["validation"] & tiles["train"]),
    "pairs_csv_rows": len(rows),
    "pairs_csv_example": rows[0]["image"] if rows else None,
    "extracted_member_example": sorted(members)[0],
    "pairs_csv_names_match_extracted": all(r["image"] in members and r["label"] in members for r in rows),
}
save()

results["elapsed_s"] = round(time.time() - t_start, 1)
save()
print(json.dumps(results["P10_sample_static"], indent=1))
print(json.dumps({k: results[k] for k in ("P2_tooling", "P3_byod_loader", "P6_summary", "P7_summary", "P8_summary", "P9_summary")}, indent=1, default=str))
print("default:", [(s["cell"], s["ok"], s.get("error")) for s in seq_default])
print("elapsed", results["elapsed_s"])
